var solace = require("solclientjs");

var numOfMessages;
var mySessionProperties = new solace.SessionProperties();
mySessionProperties.reapplySubscriptions = true;

var fs = require("fs");
try {
	var jsonString = fs.readFileSync("./arguments.json").toString();
	var obj = JSON.parse(jsonString);
	
	mySessionProperties.userName = obj.userName;
	mySessionProperties.password = obj.password;
	mySessionProperties.vpnName = obj.vpnName;
	mySessionProperties.url = obj.url;
	numOfMessages = obj.numOfMessages;

} catch (err) {
	console.warn("The file 'arguments.json' does not exist or contains invalid arguments! Exiting...");
	process.exit(1);
	
}

var counter = 1;
var topic = solace.SolclientFactory.createTopic("mytopic");
var mySession = solace.SolclientFactory.createSession(mySessionProperties,
		new solace.MessageRxCBInfo(function(session, message) {
		
				console.log();
				console.log("Received message " + counter + " out of " + numOfMessages + " messages expected");
				console.log(message.dump());
				
				counter += 1;
				if (counter > numOfMessages) {
					mySession.dispose();
				}
				
		}, this),
		new solace.SessionEventCBInfo(function(session, event) {
		
			console.log(event.toString());
			
			if (event.sessionEventCode === solace.SessionEventCode.UP_NOTICE) {
				var requestConfirmation = true;
				mySession.subscribe(topic, requestConfirmation);
			}
		}, this));
		
mySession.connect();
