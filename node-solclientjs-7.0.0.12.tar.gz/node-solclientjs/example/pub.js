var solace = require("solclientjs");

var numOfMessages;
var mySessionProperties = new solace.SessionProperties();
mySessionProperties.reapplySubscriptions = true;

var fs = require("fs");
try {

	var jsonString = fs.readFileSync("./arguments.json").toString();
	var obj = JSON.parse(jsonString);
	
	mySessionProperties.userName = obj.userName;
	mySessionProperties.password = obj.password;
	mySessionProperties.vpnName = obj.vpnName;
	mySessionProperties.url = obj.url;
	numOfMessages = obj.numOfMessages;
} catch (err) {
	
	console.warn("The file 'arguments.json' does not exist or contains invalid arguments! Exiting...");
	process.exit(1);
}

var topic = solace.SolclientFactory.createTopic("mytopic");
var mySession = solace.SolclientFactory.createSession(mySessionProperties,
		new solace.MessageRxCBInfo(function(session, message) {
		
				console.log();
				console.log("Message received!");
				console.log(message.dump());
		}, this),
		new solace.SessionEventCBInfo(function(session, event) {
		
			console.log(event.toString());
			
			if (event.sessionEventCode === solace.SessionEventCode.UP_NOTICE) {
				
				// Set a time interval for sending messages so they don't arrive all at once
				var baseTime = 1000;
				for (var i = 1; i <= numOfMessages; i++) {
					
					setTimeout(sendMessage, baseTime * i, i, numOfMessages);
				}
				
				// Disconnect from appliance after messages have been sent
				setTimeout(function() {

					mySession.dispose();
				}, baseTime * (numOfMessages + 1));
			}
		}, this));
mySession.connect();

function sendMessage(curr, total) {
	
	var message = solace.SolclientFactory.createMessage();
	message.setDestination(topic);
	mySession.send(message);
	console.log("Message " + curr + " of " + total + " sent.");
}