               Solace Systems Messaging API for Node.js
               -----------------------------------------
         Copyright 2011-2014 Solace Systems, Inc.  All rights reserved.

INTRODUCTION
    This is the Solace Systems Messaging API for JavaScript API (solclientjs).
    This API allows JavaScript applications to send and receive messages to a
    Solace appliance running SolOS-Topic Routing (TR).

SUPPORTED PLATFORMS
    Solclientjs has been tested to work with the following releases of Node.js 
	http://nodejs.org)
		- 0.6.12
		- 0.8.2

PACKAGING
    A tar.gz package is included with this distribution. The file is named 
	node-solclientjs-<version>.tar.gz and includes:
	
    /lib                      JavaScript module files

    /example                  API samples
	
    /docs                     API online docs		

INSTALLATION
    To install the node-solclientjs and run the included samples please follow 
	the steps below (assuming that node.js and npm are properly installed):
	
	- Change directory to where node-solclientjs-<version>.tar.gz is located and type:
	
	  > npm install node-solclientjs-<version>.tar.gz 
	  
	- To run the samples go to node_modules/solclientjs/example, modify
	  arguments.json to point to the appliance you wish to communicate with and specify
	  the client's user name and password. Then, type the following to run the consumer:
	  
	  > node sub.js
	  
	  and type (from a different terminal):
	  
	  > node pub.js 
	  
	  to run the producer.
	
DEBUGGING AND LOGGING
	Several versions of the API are available to support debugging and logging.
	
	Loading the production API:
		
		var solace = require('solclientjs'); 
	OR	var solace = require('solclientjs').production; // same as previous
		
		This API is minified and does not perform logging.
		
	Loading the debug API:
		
		var solace = require('solclientjs').debug; // logging supported
		solace.SolclientFactory.setLogLevel(solace.LogLevel.DEBUG); // debug logging
		
		This API is not minified and logging is enabled.
		
	Loading the unminified production API:
	
		var solace = require('solclientjs').full; // logging not supported
		
		This API does not perform logging, but is not minified to ease debugging.
	
